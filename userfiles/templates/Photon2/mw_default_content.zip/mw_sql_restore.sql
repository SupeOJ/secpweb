
REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data) VALUES('1','Sony ','','8','content','2015-01-26 15:11:38','2015-01-26 15:11:38','898','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','1','','0','','','1','W10='); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data) VALUES('2','Sony ','','8','content','2015-02-02 13:05:44','2015-02-02 13:05:44','898','','1109080999d2d15fdf4dea3e2816bc68c870a413','1','','0','','','','W10='); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('1','2015-01-26 13:16:55','2015-01-26 13:16:55','','','','page','','','Home','0','','','','','','','1','1','0','0','0','','','','static','','','','','index.php','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('2','2015-01-26 16:18:17','2015-01-26 13:47:31','','2','1','page','portfolio','','Portfolio','0','','','','','','','1','0','0','0','0','','0','','dynamic','','','','','layouts__portfolio.php','','','default','d99bbdb0025b5ca3868e457310ddb87b0a26b879','2015-01-26 16:18:17'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('3','2015-01-26 16:18:17','2015-01-26 13:49:13','','2','1','post','silviu-mustatea','','SILVIU MUSTATEA','2','','','','','
                <div class="element" id="row_1422289016499">
                  <p id="row_1418121857386" class="element">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi a odio aliquet, ornare felis vehicula, dapibus urna. Fusce nec nisl nisi. Sed vitae nibh vitae elit sollicitudin condimentum sed vel lectus. Maecenas odio massa, imperdiet ultricies diam quis, blandit vehicula est. Quisque suscipit dolor nec ante efficitur egestas. Cras dictum diam ut hendrerit semper. Fusce vitae diam erat. Sed non cursus dolor. Suspendisse vehicula sed ante sed volutpat.</p>
<p id="row_1418121857386" class="element"><span style="line-height: 1.85;">Maecenas non purus at augue faucibus pulvinar. Cras volutpat volutpat magna at tempus. In eleifend, nulla eget egestas pellentesque, nisl mi pellentesque purus, vel imperdiet nibh orci sed ipsum. Etiam ullamcorper commodo luctus. Aliquam et tincidunt magna. Ut scelerisque lacus sed ex faucibus finibus.  Mauris faucibus efficitur massa, quis molestie tellus sagittis a. Etiam odio ligula, pretium sed aliquam eget, interdum id leo.</span></p>
<p id="row_1418121856609" class="element">Aliquam vulputate condimentum erat eget malesuada. Nunc augue arcu, pharetra non ullamcorper ac, rutrum et enim. Maecenas sagittis libero ac dapibus lobortis. Donec efficitur dapibus nulla at lobortis. Nulla posuere tincidunt risus, at scelerisque ex accumsan ac. Quisque vehicula ex ac mauris euismod pharetra.  Aliquam vitae nisl lobortis nunc vulputate rutrum id ac ante. Maecenas at condimentum mauris. Nulla vitae nisi ut nisi cursus vestibulum sit amet ac mauris. Quisque molestie tellus nec accumsan sodales. Etiam sollicitudin consectetur feugiat. Integer placerat mattis ante quis dictum.</p>
<p id="row_1418121856629" class="element">Proin ac pellentesque mi. Aliquam sodales non lectus sed placerat.  Suspendisse non fringilla metus. Phasellus in ultrices eros. Donec vitae est tempus nunc laoreet ornare. Praesent in lacus sed odio auctor tincidunt at et metus. Donec consequat euismod risus, a fringilla lacus volutpat eget. Proin nunc nunc, bibendum nec dui et, mollis volutpat ipsum. Vivamus venenatis magna nec malesuada fringilla. </p>
<p id="row_1418121856861" class="element">Curabitur risus odio, tempor quis porta id, aliquet a nisi. Nulla mattis libero et ipsum eleifend mollis. Fusce accumsan augue orci. Duis feugiat tincidunt sapien. Nullam eu suscipit erat, id interdum lectus. Nulla vel scelerisque eros. Sed auctor velit vel augue viverra, sagittis aliquam sem pulvinar. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur rhoncus tellus nisi, vel mollis turpis vestibulum cursus. Proin risus nisi, finibus at turpis vitae, pellentesque tristique urna. Etiam dolor velit, placerat eget pharetra non, tincidunt sollicitudin neque.</p>
<p id="row_1418121857926" class="element">Ut commodo tristique neque, in efficitur massa venenatis et. Curabitur imperdiet, neque vel vestibulum mollis, risus ex efficitur nunc, a pretium tellus nisl in dui. Quisque pharetra nulla pulvinar arcu eleifend pellentesque.</p>
                </div>
              ','','1','0','0','0','0','','0','','post','','','','','inherit','','','','d99bbdb0025b5ca3868e457310ddb87b0a26b879','2015-01-26 13:49:13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('4','2015-01-26 15:22:25','2015-01-26 14:07:35','','2','1','page','blog','','Blog','0','','','','','','','1','0','0','0','0','','0','','dynamic','','','','','layouts__blog.php','','','default','c1bf5f715ae1776542c99c556825037880e99461','2015-01-26 15:22:25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('5','2015-01-26 15:22:40','2015-01-26 14:10:14','','2','1','post','proin-blandit-ligula-non-erat-malesuada-accumsan','','Proin blandit ligula non erat malesuada accumsan','4','','','','','
                        <module class="module module module-pictures " data-mw-title="Picture Gallery" id="module-pictures-editor_tools1046843207" data-type="pictures" data-template="simple" rel="content"></module><div class="element">
    						<p align="justify" class=" element" id="row_1422281289670">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>
    					</div>
    				','','1','0','0','0','0','','0','','post','','','','','inherit','','','','c1bf5f715ae1776542c99c556825037880e99461','2015-01-26 14:10:14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('6','2015-01-26 15:07:54','2015-01-26 14:41:53','','2','1','page','shop','','Shop','0','','','','','','','1','0','0','1','0','','0','','dynamic','','','','','layouts__shop.php','','','default','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','2015-01-26 15:07:54'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('7','2015-01-26 14:43:55','2015-01-26 14:43:55','','2','2','page','contact-me','','Contact Me','0','','','','','','','1','0','0','0','0','','0','','static','','','','','layouts__contacts.php','','','default','73c781c57da86d63a89a2638f8dfda1086e281e9','2015-01-26 14:43:55'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('8','2015-01-26 16:24:12','2015-01-26 14:49:43','','1','1','product','sony','','Sony ','6','','','','','
      					<ul>
<li>40 megapixel CCD sensor provides a top resolution of 7264x5440</li>
<li>Fully weather sealed and coldproof design resists rain, snow, dust and other environmental hazards during field use</li>
<li>14 Bit RAW files in Pentax PEF and Adobe DNG formats</li>
<li>Dual slot SD/SDHC memory card support</li>
<li>Responsive 11 point SAFOX IX+autofocus system features a light wavelength sensor for improved focusspeed even in different lighting environments<span style="line-height: 1.5;">.</span>
</li>
</ul>
','','1','0','0','0','0','','0','','','','','','','inherit','','','','d99bbdb0025b5ca3868e457310ddb87b0a26b879','2015-01-26 14:49:43'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,updated_at,created_at,expires_at,created_by,edited_by,content_type,url,content_filename,title,parent,description,content_meta_title,content_meta_keywords,position,content,content_body,is_active,is_home,is_pinged,is_shop,is_deleted,draft_of,require_login,status,subtype,subtype_value,custom_type,custom_type_value,original_link,layout_file,layout_name,layout_style,active_site_template,session_id,posted_at) VALUES('9','2015-01-26 15:07:54','2015-01-26 15:07:54','','1','1','product','pentax-645d','','Pentax 645D','6','','','','','','','1','0','0','0','0','','0','','','','','','','inherit','','','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','2015-01-26 15:07:54'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('1','2015-01-26 14:49:43','2015-01-26 14:49:43','1','1','8','qty','nolimit','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('2','2015-01-26 14:49:43','2015-01-26 14:49:43','1','1','8','sku','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('3','2015-01-26 14:49:43','2015-01-26 14:49:43','1','1','8','shipping_weight','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('4','2015-01-26 14:49:43','2015-01-26 14:49:43','1','1','8','shipping_width','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('5','2015-01-26 14:49:43','2015-01-26 14:49:43','1','1','8','shipping_height','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('6','2015-01-26 14:49:43','2015-01-26 14:49:43','1','1','8','shipping_depth','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('7','2015-01-26 14:49:43','2015-01-26 14:49:43','1','1','8','additional_shipping_cost','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('8','2015-01-26 15:07:54','2015-01-26 15:07:54','1','1','9','qty','nolimit','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('9','2015-01-26 15:07:54','2015-01-26 15:07:54','1','1','9','sku','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('10','2015-01-26 15:07:54','2015-01-26 15:07:54','1','1','9','shipping_weight','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('11','2015-01-26 15:07:54','2015-01-26 15:07:54','1','1','9','shipping_width','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('12','2015-01-26 15:07:54','2015-01-26 15:07:54','1','1','9','shipping_height','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('13','2015-01-26 15:07:54','2015-01-26 15:07:54','1','1','9','shipping_depth','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('14','2015-01-26 15:07:54','2015-01-26 15:07:54','1','1','9','additional_shipping_cost','','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('1','module','contact-form','0','name','Name','name','2015-01-26 14:43:47','2015-01-26 14:43:47','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('2','module','contact-form','1','email','Email','email','2015-01-26 14:43:47','2015-01-26 14:43:47','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('3','module','contact-form','2','message','Message','message','2015-01-26 14:43:47','2015-01-26 14:43:47','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('4','content','8','','price','price','price','2015-01-26 14:48:02','2015-01-26 14:47:14','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('5','content','9','','price','price','price','2015-01-26 15:07:54','2015-01-26 14:50:10','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('6','module','shipping-info-module-shop-shipping-gateways-country557478767','0','address','Address','address','2015-01-26 15:11:41','2015-01-26 15:11:41','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('7','module','shipping-info-module-shop-shipping-gateways-country55747876754c6592dce651','0','address','Address','address','2015-01-26 15:11:41','2015-01-26 15:11:41','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('8','module','shipping-info-module-shop-shipping-gateways-country55747876754c6592dd2717','0','address','Address','address','2015-01-26 15:11:41','2015-01-26 15:11:41','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('9','module','shipping-info-module-shop-shipping-gateways-country55747876754c6592dd5ef3','0','address','Address','address','2015-01-26 15:11:41','2015-01-26 15:11:41','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('10','module','shipping-info-module-shop-shipping-gateways-country55747876754c6592ddb669','0','address','Address','address','2015-01-26 15:11:41','2015-01-26 15:11:41','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('11','module','shipping-info-module-shop-shipping-gateways-country55747876754c659392024b','0','address','Address','address','2015-01-26 15:11:53','2015-01-26 15:11:53','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('12','module','shipping-info-module-shop-shipping-gateways-country55747876754c6593924670','0','address','Address','address','2015-01-26 15:11:53','2015-01-26 15:11:53','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('13','module','shipping-info-module-shop-shipping-gateways-country55747876754c6593927e31','0','address','Address','address','2015-01-26 15:11:53','2015-01-26 15:11:53','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('14','module','shipping-info-module-shop-shipping-gateways-country55747876754c659392d39c','0','address','Set Your Address','set-your-address','2015-01-26 15:13:27','2015-01-26 15:11:53','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('15','module','shipping-info-module-shop-shipping-gateways-country55747876754c65b47a3b8f','0','address','Address','address','2015-01-26 15:20:39','2015-01-26 15:20:39','','','b6e00d79a1ba2b1737b0af031de0d6c583a0961a','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('16','module','shipping-info-module-shop-shipping-gateways-country55747876754c65b47a8a35','0','address','Address','address','2015-01-26 15:20:39','2015-01-26 15:20:39','','','b6e00d79a1ba2b1737b0af031de0d6c583a0961a','','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('1','4','898','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('2','5','4888','0'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('1','2015-01-26 13:50:54','2015-01-26 13:50:54','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','1','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/2048_4_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('2','2015-01-26 13:50:57','2015-01-26 13:50:57','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','4','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/2048_5_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('3','2015-01-26 13:51:02','2015-01-26 13:51:02','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','2','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/2048.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('4','2015-01-26 13:51:09','2015-01-26 13:51:09','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','3','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/20481.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('5','2015-01-26 13:51:10','2015-01-26 13:51:10','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','5','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Gord_Weber.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('6','2015-01-26 13:51:12','2015-01-26 13:51:12','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','6','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Igor_Protchenko_1_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('7','2015-01-26 13:51:19','2015-01-26 13:51:19','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','7','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Igor_Protchenko.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('8','2015-01-26 13:51:21','2015-01-26 13:51:21','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','8','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Jon_Inge_Nordnes.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('9','2015-01-26 13:51:23','2015-01-26 13:51:23','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','9','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Olena_Zaskochenko.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('10','2015-01-26 13:51:26','2015-01-26 13:51:26','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','10','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Silviu_Mustatea_1_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('11','2015-01-26 13:51:30','2015-01-26 13:51:30','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','3','picture','0','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Silviu_Mustatea.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('12','2015-01-26 14:09:20','2015-01-26 14:09:20','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','5','picture','2','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/8683795034_9f34684a6b_o.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('13','2015-01-26 14:09:28','2015-01-26 14:09:28','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','5','picture','1','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/14304506980_dd976d7cd5_o.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('14','2015-01-26 14:09:47','2015-01-26 14:09:47','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','5','picture','3','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/14511270173_19104dfbcb_o.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('15','2015-01-26 14:09:48','2015-01-26 14:09:48','2','2','73c781c57da86d63a89a2638f8dfda1086e281e9','content','5','picture','0','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/a1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('16','2015-01-26 14:47:47','2015-01-26 14:47:47','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/20141202142614sony_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('17','2015-01-26 14:47:49','2015-01-26 14:47:49','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/20141202142711sony_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('18','2015-01-26 14:47:50','2015-01-26 14:47:50','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/20141202142711sony_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('19','2015-01-26 15:07:28','2015-01-26 15:07:28','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9','picture','9999999','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/20141202142918pentax_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('20','2015-01-26 15:07:29','2015-01-26 15:07:29','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9','picture','9999999','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/20141202142918pentax_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('21','2015-01-26 15:07:31','2015-01-26 15:07:31','1','1','d8da5f9cf05c50872f16970d00508eb7e2c0c1a7','content','9','picture','9999999','','','','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/20141202142918pentax_3.jpg'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('1','header_menu','menu','','','','','2015-01-26 13:16:55','2015-01-26 13:16:55','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('2','','menu_item','1','1','','0','2015-01-26 13:16:55','2015-01-26 13:16:55','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('3','','menu_item','1','6','','2','2015-01-26 14:42:38','2015-01-26 14:42:38','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('4','','menu_item','1','4','','3','2015-01-26 14:42:53','2015-01-26 14:42:53','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('5','','menu_item','1','7','','4','2015-01-26 14:43:55','2015-01-26 14:43:55','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('6','','menu_item','1','2','','1','2015-01-26 15:08:48','2015-01-26 15:08:48','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('1','2015-01-26 13:16:55','2015-01-26 13:16:55','current_template','photon','','','','template','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('2','2015-01-26 13:53:39','2015-01-26 13:53:39','display_comments_from','current','','','','module-comments-silviu-mustatea2607441462','','','','','comments',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('3','2015-01-26 13:58:04','2015-01-26 13:57:41','colorscheme','dark','','','','mw-template-photon','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('4','2015-01-26 14:04:02','2015-01-26 14:02:39','enable_comments','y','','','','comments','','','','','comments',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('5','2015-01-26 14:03:03','2015-01-26 14:03:03','display_comments_from','current','','','','module-comments-editor_tools2607441462','','','','','comments',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('6','2015-01-26 14:04:03','2015-01-26 14:03:51','disable_new_comments','','','','','module-comments-editor_tools2607441462','','','','','comments',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('7','2015-01-26 14:44:26','2015-01-26 14:44:26','facebook_enabled','y','','','','nav-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('8','2015-01-26 14:44:29','2015-01-26 14:44:29','twitter_enabled','y','','','','nav-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('9','2015-01-26 14:44:30','2015-01-26 14:44:30','googleplus_enabled','y','','','','nav-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('10','2015-01-26 14:44:31','2015-01-26 14:44:31','pinterest_enabled','y','','','','nav-social-links','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('11','2015-01-26 14:44:59','2015-01-26 14:44:59','logoimage','{SITE_URL}userfiles/media/photon-content-microweber-com/uploaded/Logo_Photon_LENS.png','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('12','2015-01-26 14:44:59','2015-01-26 14:44:59','size','auto','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('13','2015-01-26 14:45:05','2015-01-26 14:45:05','text','PHOTON','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('14','2015-01-26 15:09:22','2015-01-26 15:09:22','data-page-id','2','','','','portfolio-posts','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('15','2015-01-26 15:10:16','2015-01-26 15:10:16','shipping_gw_shop/shipping/gateways/country','y','','','','shipping','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('16','2015-01-26 15:10:45','2015-01-26 15:10:45','payment_gw_shop/payments/gateways/pay_on_delivery','1','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('17','2015-01-26 15:10:46','2015-01-26 15:10:46','pay_on_delivery_show_msg','y','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('18','2015-01-26 15:11:12','2015-01-26 15:11:12','pay_on_delivery_msg','Need to make payment on delivery','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('19','2015-01-26 15:11:15','2015-01-26 15:11:15','paypalexpress_testmode','y','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('20','2015-01-26 15:11:16','2015-01-26 15:11:16','payment_gw_shop/payments/gateways/paypal','1','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('21','2015-02-24 14:38:29','2015-02-24 14:38:29','website_title','Microweber','','','','website','','','','','',''); /* MW_QUERY_SEPERATOR */





